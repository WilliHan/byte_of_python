print("Hello World !! from Bitbucket")
print("결과값은", 2*7, "입니다.")
print("Welcome World !! from Local")
