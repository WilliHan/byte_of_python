age=20
name='Swaroop'

print ('[00] {0} was {1} years old when he wrote this book'.format(name,age))
print ('[01] Why is {0} playing with that python?'.format(name))

print ('[02] ' + name + ' is ' + str(age) + ' years old')

print ('[03] {} was {} years old when he wrote this book'.format(name,age))
print ('[04] Why is {} playing with that python?'.format(name))

print ('{0:.3f}'.format(1.0/3))
print ('{0:_^11}'.format('hello'))
print ('{name} wrote {book}'.format(name='Swaroop', book='A Byte of Python'))

print ("This is the first sentence. \
This is the second sentence.")

print (r"Newlines are indicated by \n")

i = 5
print ('Value is ', i)
print ('I repeat, the value is ', i)
